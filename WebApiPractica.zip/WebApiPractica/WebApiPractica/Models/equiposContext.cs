﻿using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace WebApiPractica.Models
{
    public class equiposContext : DbContext
    {
        public equiposContext(DbContextOptions<equiposContext> options) : base(options)
        {

        }

        public DbSet<equipos> equipos { get; set; }
        public DbSet<TipoEquipo> tipo_equipo { get; set; }
        public DbSet<Marca> marcas { get; set; }
        public DbSet<EstadoEquipo> estados_equipo { get; set; }

    }

}

