﻿namespace WebApiPractica.Models
{
    public class categorias
    {
    }
}
